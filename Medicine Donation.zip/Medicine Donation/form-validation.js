signupForm.addEventListener('submit', (event) => {
  const fullNameValue = fullNameInput.value.trim();
  const phoneNumberValue = phoneNumberInput.value.trim();
  const emailValue = signupEmailInput.value.trim();
  const passwordValue = signupPasswordInput.value.trim();
  const confirmPasswordValue = signupConfirmPasswordInput.value.trim();
  let emailValid = true;
  let passwordValid = true;
  let confirmPasswordValid = true;
  let fullNameValid = true;
  let phoneNumberValid = true;

  if (emailValue === '') {
    showError(signupEmailError, 'Enter email');
    emailValid = false;
  } else if (!validateEmail(emailValue)) {
    showError(signupEmailError, 'Invalid email format');
    emailValid = false;
  } else {
    clearError(signupEmailError);
  }

  const passwordValidationMessage = validatePassword(passwordValue);
  if (passwordValidationMessage !== '') {
    showError(signupPasswordError, passwordValidationMessage);
    passwordValid = false;
  } else {
    clearError(signupPasswordError);
  }

  if (confirmPasswordValue === '') {
    showError(signupConfirmPasswordError, 'Enter confirm password');
    confirmPasswordValid = false;
  } else if (confirmPasswordValue !== passwordValue) {
    showError(signupConfirmPasswordError, 'Passwords do not match');
    confirmPasswordValid = false;
  } else {
    clearError(signupConfirmPasswordError);
  }

  if (fullNameValue === '') {
    showError(fullNameError, 'Enter full name');
    fullNameValid = false;
  } else {
    clearError(fullNameError);
  }

  phoneNumberInput.addEventListener('blur', () => {
  const phoneNumberValue = phoneNumberInput.value.trim();
  if (phoneNumberValue === '') {
    showError(phoneNumberError, 'Enter phone number');
  } else if (!validatePhoneNumber(phoneNumberValue)) {
    showError(phoneNumberError, 'Phone number must contain 10 digits');
  } else {
    clearError(phoneNumberError);
  }
});

function validatePhoneNumber(phoneNumber) {
  const phoneNumberRegex = /^\d{10}$/; // Regular expression for exactly 10 digits
  return phoneNumberRegex.test(phoneNumber);
}

  if (!emailValid || !passwordValid || !confirmPasswordValid || !fullNameValid || !phoneNumberValid) {
    event.preventDefault();
  }
});

  const loginEmailInput = document.querySelector('#loginEmailInput');
  const loginPasswordInput = document.querySelector('#loginPasswordInput');
  const loginEmailError = document.querySelector('#loginEmailError');
  const loginPasswordError = document.querySelector('#loginPasswordError');
  const loginForm = document.querySelector('#loginForm');


  function validateEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  function validatePassword(password) {
    const passwordRegex = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*\W)(?!.*\s).{8,}$/;

    if (!passwordRegex.test(password)) {
      if (!/(?=.*\d)/.test(password)) {
        return 'Password must contain a number';
      } else if (!/(?=.*[a-z])/.test(password)) {
        return 'Password must contain a lowercase letter';
      } else if (!/(?=.*[A-Z])/.test(password)) {
        return 'Password must contain an uppercase letter';
      } else if (!/(?=.*\W)/.test(password)) {
        return 'Password must contain a special character';
      } else if (password.length < 8) {
        return 'Password must be at least 8 characters long';
      }
    }

    return '';
  }

  function showError(element, message) {
    element.textContent = message;
    element.style.color = 'yellow';
  }

  function clearError(element) {
    element.textContent = '';
  }

  loginEmailInput.addEventListener('blur', () => {
    const emailValue = loginEmailInput.value.trim();
    if (emailValue === '') {
      showError(loginEmailError, 'Enter email');
    } else if (!validateEmail(emailValue)) {
      showError(loginEmailError, 'Invalid email format');
    } else {
      clearError(loginEmailError);
    }
  });

  loginPasswordInput.addEventListener('blur', () => {
    const passwordValue = loginPasswordInput.value.trim();
    const passwordValidationMessage = validatePassword(passwordValue);
    
    if (passwordValidationMessage !== '') {
      showError(loginPasswordError, passwordValidationMessage);
    } else {
      clearError(loginPasswordError);
    }
  });

  loginForm.addEventListener('submit', (event) => {
    const emailValue = loginEmailInput.value.trim();
    const passwordValue = loginPasswordInput.value.trim();
    let emailValid = true;
    let passwordValid = true;

    if (emailValue === '') {
      showError(loginEmailError, 'Enter email');
      emailValid = false;
    } else if (!validateEmail(emailValue)) {
      showError(loginEmailError, 'Invalid email format');
      emailValid = false;
    } else {
      clearError(loginEmailError);
    }

    const passwordValidationMessage = validatePassword(passwordValue);
    if (passwordValidationMessage !== '') {
      showError(loginPasswordError, passwordValidationMessage);
      passwordValid = false;
    } else {
      clearError(loginPasswordError);
    }

    if (!emailValid || !passwordValid) {
      event.preventDefault();
    }
    
  });